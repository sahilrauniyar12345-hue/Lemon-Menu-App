package com.example.littlelemon.ui.theme

import androidx.compose.ui.graphics.Color

val LittleLemonGreen = Color(0xFF495E57)
val LittleLemonYellow = Color(0xFFF4CE14)