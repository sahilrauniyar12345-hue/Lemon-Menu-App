package com.example.littlelemon

val menuItems = listOf(
    MenuItem(1, "Greek Salad", "Fresh salad with feta cheese", "$12"),
    MenuItem(2, "Pasta", "Pasta with tomato sauce", "$15"),
    MenuItem(3, "Lemon Dessert", "Traditional lemon dessert", "$8")
)