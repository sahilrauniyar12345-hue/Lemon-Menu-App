package com.example.littlelemon.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = LittleLemonGreen,
    secondary = LittleLemonYellow
)

@Composable
fun LittleLemonTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}