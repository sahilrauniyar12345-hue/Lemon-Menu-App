package com.example.littlelemon

data class MenuItem(
    val id: Int,
    val title: String,
    val description: String,
    val price: String
)