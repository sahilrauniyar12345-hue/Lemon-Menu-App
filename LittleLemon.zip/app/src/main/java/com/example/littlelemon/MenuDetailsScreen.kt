package com.example.littlelemon

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MenuDetailsScreen(id: Int) {
    val item = menuItems.first { it.id == id }
    Column(modifier = Modifier.padding(16.dp)) {
        Text(item.title, style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(item.description)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Price: ${item.price}")
    }
}