package com.example.littlelemon

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun MenuScreen(navController: NavController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Little Lemon Menu", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        menuItems.forEach {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable { navController.navigate("details/${it.id}") }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(it.title, style = MaterialTheme.typography.titleLarge)
                    Text(it.price)
                }
            }
        }
    }
}